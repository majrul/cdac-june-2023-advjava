function add(x, y) {
    return x + y;
}

console.log("welcome to the world of containerization!");
console.log(add(10, 20));