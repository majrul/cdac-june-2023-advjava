package com.cdac;

//javac -d target/classes src/main/java/com/cdac/HelloWorld.java
//java -cp target/classes com.cdac.HelloWorld
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
